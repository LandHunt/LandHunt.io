"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";

declare global {
  interface Window {
    Outseta?: any;
    o_options?: any;
  }
}

const fontFamily =
  "-apple-system, BlinkMacSystemFont, system-ui, 'SF Pro Text', sans-serif";

export default function NavBar() {
  const pathname = usePathname();

  const isActive = (href: string) => {
    if (href === "/dashboard") return pathname === "/dashboard" || pathname === "/";
    return pathname === href || pathname.startsWith(href + "/");
  };

  const tabs = [
    { href: "/dashboard", label: "Explore" },
    { href: "/projects", label: "My Sites" },
    { href: "/marketplace", label: "Marketplace" },
    { href: "/clients", label: "My Clients" },
    { href: "/companies", label: "Companies" },
  ];

  const [ready, setReady] = useState(false);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    let tries = 0;
    const i = setInterval(async () => {
      tries++;
      if (window.Outseta?.getUser) {
        clearInterval(i);
        setReady(true);
        try {
          const u = await window.Outseta.getUser();
          setUser(u || null);
        } catch {
          setUser(null);
        }
        window.Outseta.on?.("accessToken.set", async () => {
          try {
            const u = await window.Outseta.getUser();
            setUser(u || null);
          } catch {
            setUser(null);
          }
        });
      } else if (tries > 100) {
        clearInterval(i);
      }
    }, 100);
    return () => clearInterval(i);
  }, []);

  return (
    <div
      style={{
        position: "fixed",
        top: 10,
        left: 16,
        right: 16,
        zIndex: 50,
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        fontFamily,
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 6,
          padding: 4,
          borderRadius: 999,
          background: "rgba(15,23,42,0.94)",
          border: "1px solid rgba(30,64,175,0.6)",
          boxShadow: "0 12px 25px rgba(15,23,42,0.7)",
        }}
      >
        {tabs.map((tab) => {
          const active = isActive(tab.href);
          return (
            <Link
              key={tab.href}
              href={tab.href}
              style={{
                padding: "6px 14px",
                borderRadius: 999,
                fontSize: 12.5,
                fontWeight: 500,
                textDecoration: "none",
                background: active
                  ? "linear-gradient(135deg,#2563eb,#1d4ed8)"
                  : "transparent",
                color: active ? "white" : "rgba(226,232,240,0.9)",
                border: active
                  ? "1px solid rgba(191,219,254,0.9)"
                  : "1px solid transparent",
                boxShadow: active ? "0 10px 20px rgba(37,99,235,0.45)" : "none",
                whiteSpace: "nowrap",
              }}
            >
              {tab.label}
            </Link>
          );
        })}
      </div>

      {ready && (
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          {user ? (
            <>
              <button
                type="button"
                onClick={() => window.Outseta?.profile.open({ mode: "popup" })}
                style={btnStyle}
              >
                {user?.FirstName || user?.Email || "Account"}
              </button>
              <a href="/api/outseta/logout" style={btnLinkStyle}>
                Log out
              </a>
            </>
          ) : (
            <>
              <button
                type="button"
                onClick={() =>
                  window.Outseta?.auth.open({ type: "login", mode: "popup" })
                }
                style={btnStyle}
              >
                Log in
              </button>
              <button
                type="button"
                onClick={() =>
                  window.Outseta?.auth.open({ type: "signup", mode: "popup" })
                }
                style={btnStylePrimary}
              >
                Create account
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
}

const btnStyle: React.CSSProperties = {
  padding: "6px 12px",
  borderRadius: 10,
  border: "1px solid rgba(148,163,184,0.35)",
  background: "rgba(15,23,42,0.95)",
  color: "white",
  cursor: "pointer",
  fontSize: 12.5,
};

const btnStylePrimary: React.CSSProperties = {
  ...btnStyle,
  border: "1px solid rgba(191,219,254,0.9)",
  background: "linear-gradient(135deg,#2563eb,#1d4ed8)",
};

const btnLinkStyle: React.CSSProperties = {
  ...btnStyle,
  textDecoration: "none",
  display: "inline-block",
};

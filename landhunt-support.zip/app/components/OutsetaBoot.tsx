"use client";

import { useEffect } from "react";

export default function OutsetaBoot() {
  useEffect(() => {
    const w = window as any;
    if (w.Outseta) return;

    w.o_options = {
      auth: {
        login:  { mode: "popup", successUrl: window.location.href },
        signup: { mode: "popup", successUrl: window.location.href },
      },
    };

    const s = document.createElement("script");
    s.src = "https://cdn.outseta.com/latest/outseta.min.js";
    s.async = true;
    s.onload = () => {
      const O = (window as any).Outseta;
      if (!O) return;
      O.on?.("accessToken.set", async () => {
        try { await O.getUser(); } finally { window.location.reload(); }
      });
    };
    document.head.appendChild(s);

    return () => { try { document.head.removeChild(s); } catch {} };
  }, []);

  return null;
}

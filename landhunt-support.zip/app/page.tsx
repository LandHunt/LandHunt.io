// app/page.tsx
"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

declare global {
  interface Window {
    Outseta?: any;
  }
}

export default function HomePage() {
  const router = useRouter();
  const [ready, setReady] = useState(false);

  // We keep the Outseta bootstrap so you can re-enable it later,
  // but for now we bypass auth and let buttons push to /dashboard.
  useEffect(() => {
    let tries = 0;
    const t = setInterval(async () => {
      tries++;
      if (typeof window !== "undefined") {
        // Mark UI ready quickly even if Outseta isn't present yet
        setReady(true);
      }
      if (window.Outseta) {
        clearInterval(t);
        // If you want auto-redirect for logged-in users later, uncomment:
        // try {
        //   const user = await window.Outseta.getUser();
        //   if (user) router.replace("/dashboard");
        // } catch {}
        // window.Outseta.on?.("accessToken.set", () => router.replace("/dashboard"));
      } else if (tries > 100) {
        clearInterval(t); // ~10s timeout
      }
    }, 100);
    return () => clearInterval(t);
  }, [router]);

  return (
    <main style={styles.page}>
      {/* Top bar */}
      <header style={styles.header}>
        <div style={styles.brand}>
          <div style={styles.logoDot} />
          <span>Landhunt</span>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          {/* TEMP BYPASS: go straight to dashboard */}
          <button
            disabled={!ready}
            onClick={() => router.push("/dashboard")}
            style={{ ...btnBase, ...btnGhost }}
          >
            Log in
          </button>
          <button
            disabled={!ready}
            onClick={() => router.push("/dashboard")}
            style={{ ...btnBase, ...btnPrimary }}
          >
            Sign up
          </button>
        </div>
      </header>

      {/* Hero */}
      <section style={styles.heroWrap}>
        <div style={styles.heroCard}>
          <h1 style={styles.h1}>Find, assess, and plan sites faster.</h1>
          <p style={styles.sub}>
            Search UK parcels, inspect sales history, sketch shapes, and save
            candidate sites to projects—all in one place.
          </p>

          <div style={{ display: "flex", gap: 12, marginTop: 18 }}>
            {/* TEMP BYPASS: both buttons go to /dashboard */}
            <button
              disabled={!ready}
              onClick={() => router.push("/dashboard")}
              style={{ ...btnBase, ...btnPrimary, padding: "12px 18px" }}
            >
              Create free account
            </button>
            <button
              disabled={!ready}
              onClick={() => router.push("/dashboard")}
              style={{ ...btnBase, ...btnGhost, padding: "12px 18px" }}
            >
              Log in
            </button>
            <a href="/health" style={styles.link}>
              Health
            </a>
          </div>

          {/* Mini “features” without external icons */}
          <div style={styles.features}>
            {[
              { title: "UK address search", desc: "Jump to any address or postcode." },
              { title: "Nearby sales (PPD)", desc: "See recent transactions around a point." },
              { title: "Sketch lines/polygons", desc: "Draw simple shapes for quick analysis." },
              { title: "Save to projects", desc: "Bookmark promising sites to revisit." },
            ].map((f, i) => (
              <div key={i} style={styles.featureItem}>
                <div style={styles.badge} />
                <div>
                  <div style={styles.featureTitle}>{f.title}</div>
                  <div style={styles.featureDesc}>{f.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Simple footer */}
      <footer style={styles.footer}>
        <span style={{ opacity: 0.7 }}>© {new Date().getFullYear()} Landhunt</span>
        <a href="mailto:hello@landhunt.io" style={styles.footerLink}>
          Contact
        </a>
      </footer>
    </main>
  );
}

/* ---------- styles (no external CSS) ---------- */
const styles: Record<string, React.CSSProperties> = {
  page: {
    minHeight: "100vh",
    background: "radial-gradient(1200px 600px at 20% -10%, #0b1220 0, #050912 55%, #05070d 100%)",
    color: "white",
    fontFamily: "-apple-system,BlinkMacSystemFont,system-ui,'SF Pro Text',Inter,Segoe UI,Roboto,sans-serif",
    display: "flex",
    flexDirection: "column",
  },
  header: {
    height: 64,
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "0 20px",
    borderBottom: "1px solid rgba(148,163,184,0.15)",
    backdropFilter: "blur(6px)",
  },
  brand: {
    display: "flex",
    alignItems: "center",
    gap: 10,
    fontWeight: 700,
    letterSpacing: 0.2,
  },
  logoDot: {
    width: 12,
    height: 12,
    borderRadius: 999,
    background: "linear-gradient(135deg,#60a5fa,#2563eb)",
    boxShadow: "0 0 16px rgba(37,99,235,0.7)",
  },
  heroWrap: {
    display: "grid",
    placeItems: "center",
    padding: "48px 16px 32px",
    flex: 1,
  },
  heroCard: {
    width: 920,
    maxWidth: "100%",
    borderRadius: 18,
    padding: 24,
    background: "rgba(15,23,42,0.55)",
    border: "1px solid rgba(148,163,184,0.18)",
    boxShadow: "0 40px 120px rgba(2,6,23,0.65)",
  },
  h1: {
    margin: 0,
    fontSize: 36,
    lineHeight: 1.15,
    fontWeight: 800,
  },
  sub: {
    marginTop: 10,
    opacity: 0.85,
    fontSize: 16,
  },
  link: {
    alignSelf: "center",
    color: "#93c5fd",
    textDecoration: "none",
    padding: "12px 6px",
    fontWeight: 600,
  },
  features: {
    marginTop: 22,
    display: "grid",
    gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
    gap: 12,
  },
  featureItem: {
    display: "flex",
    gap: 12,
    alignItems: "flex-start",
    border: "1px solid rgba(148,163,184,0.18)",
    borderRadius: 12,
    padding: 12,
    background: "rgba(2,6,23,0.45)",
  },
  badge: {
    width: 10,
    height: 10,
    borderRadius: 999,
    marginTop: 6,
    background: "linear-gradient(135deg,#34d399,#059669)",
    boxShadow: "0 0 16px rgba(5,150,105,0.6)",
  },
  featureTitle: { fontWeight: 700, fontSize: 14.5 },
  featureDesc: { opacity: 0.8, fontSize: 13, marginTop: 2 },
  footer: {
    height: 56,
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "0 16px",
    borderTop: "1px solid rgba(148,163,184,0.15)",
  },
  footerLink: { color: "#93c5fd", textDecoration: "none" },
};

/* ---------- buttons ---------- */
const btnBase: React.CSSProperties = {
  padding: "10px 14px",
  borderRadius: 12,
  fontSize: 14,
  fontWeight: 700,
  cursor: "pointer",
  border: "1px solid transparent",
  transition: "transform 120ms ease, box-shadow 120ms ease, opacity 120ms ease",
};

const btnPrimary: React.CSSProperties = {
  background: "linear-gradient(135deg,#2563eb,#1d4ed8)",
  color: "white",
  border: "1px solid rgba(191,219,254,0.9)",
  boxShadow: "0 12px 24px rgba(37,99,235,0.35)",
};

const btnGhost: React.CSSProperties = {
  background: "rgba(15,23,42,0.95)",
  color: "white",
  border: "1px solid rgba(148,163,184,0.35)",
};

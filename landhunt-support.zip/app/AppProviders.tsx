// app/AppProviders.tsx
"use client";

import React from "react";
import OutsetaBoot from "./components/OutsetaBoot";

// TODO: <<< EDIT THIS PATH to wherever your provider lives >>>
import { ProjectsProvider } from "./projects/_lib/ProjectsContext"; 
// common alternates you might have:
// import { ProjectsProvider } from "./projects/_lib/ProjectsProvider";
// import { ProjectsProvider } from "./projects/state/ProjectsContext";

export default function AppProviders({ children }: { children: React.ReactNode }) {
  return (
    <>
      <OutsetaBoot />
      <ProjectsProvider>{children}</ProjectsProvider>
    </>
  );
}

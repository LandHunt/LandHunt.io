// app/api/clients/route.ts
import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseServer";

/** Toggle: in dev we allow 'UNSET' fallback when header missing */
const DEV_TENANT_FALLBACK = process.env.NODE_ENV !== "production";

type DbClient = {
  id: string;
  name: string;
  company: string | null;
  jobtitle: string | null;
  email: string | null;
  phone: string | null;
  stage: string | null;
  valuegbp: number | null;
  tags: string[] | null;
  siteids: string[] | null;
  activity: any[];
  documents: any[];
  created_at: string;
  account_uid: string;
  created_by: string | null;
};

const dbToApi = (r: DbClient) => ({
  id: r.id,
  name: r.name,
  company: r.company ?? undefined,
  jobTitle: r.jobtitle ?? undefined,
  email: r.email ?? undefined,
  phone: r.phone ?? undefined,
  stage: (r.stage as any) ?? "lead",
  valueGBP: r.valuegbp ?? undefined,
  tags: r.tags ?? [],
  siteIds: r.siteids ?? [],
  activity: r.activity ?? [],
  documents: r.documents ?? [],
  createdAt: r.created_at,
});

const apiToDb = (b: any): Partial<DbClient> => ({
  name: b.name?.trim(),
  company: b.company?.trim() || null,
  jobtitle: b.jobTitle?.trim() || null,
  email: b.email?.trim() || null,
  phone: b.phone?.trim() || null,
  stage: b.stage ?? "lead",
  valuegbp: typeof b.valueGBP === "number" ? b.valueGBP : null,
  tags: Array.isArray(b.tags) ? b.tags : [],
  siteids: Array.isArray(b.siteIds) ? b.siteIds : [],
  activity: Array.isArray(b.activity) ? b.activity : [],
  documents: Array.isArray(b.documents) ? b.documents : [],
});

function getTenantOrNull(req: Request) {
  const hdr = req.headers.get("x-outseta-account");
  if (hdr && hdr !== "null") return hdr;
  return null;
}

export async function GET(req: Request) {
  const tenant = getTenantOrNull(req) ?? (DEV_TENANT_FALLBACK ? "UNSET" : null);
  if (!tenant)
    return NextResponse.json({ error: "Missing tenant (x-outseta-account)" }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const company = searchParams.get("company");

  let query = supabaseAdmin
    .from("clients")
    .select("*")
    .eq("account_uid", tenant)
    .order("created_at", { ascending: false });

  if (company) query = query.eq("company", company);

  const { data, error } = await query;
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json((data as DbClient[]).map(dbToApi));
}

export async function POST(req: Request) {
  const tenant = getTenantOrNull(req) ?? (DEV_TENANT_FALLBACK ? "UNSET" : null);
  const userUid = req.headers.get("x-outseta-user") || null;

  if (!tenant)
    return NextResponse.json({ error: "Missing tenant (x-outseta-account)" }, { status: 401 });

  try {
    const body = await req.json();
    if (!body?.name?.trim())
      return NextResponse.json({ error: "Name required" }, { status: 400 });

    const payload = apiToDb({
      ...body,
      tags: body.tags ?? [],
      siteIds: body.siteIds ?? [],
      activity: [],
      documents: [],
    }) as any;

    payload.account_uid = tenant;
    payload.created_by = userUid;

    const { data, error } = await supabaseAdmin
      .from("clients")
      .insert(payload)
      .select("*")
      .single();

    if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    return NextResponse.json(dbToApi(data as DbClient));
  } catch (e: any) {
    return NextResponse.json({ error: e.message ?? "Unknown error" }, { status: 500 });
  }
}

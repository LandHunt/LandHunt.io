// app/api/clients/route.ts (POST only – replace the whole POST export)
import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseServer";

const DEV_TENANT_FALLBACK = process.env.NODE_ENV !== "production";

type DbClient = {
  id: string;
  name: string;
  company: string | null;
  jobtitle: string | null;
  email: string | null;
  phone: string | null;
  stage: string | null;
  valuegbp: number | null;
  tags: string[] | null;
  siteids: string[] | null;
  activity: any[];
  documents: any[];
  created_at: string;
  account_uid: string;
  created_by: string | null;
};

const apiToDb = (b: any): Partial<DbClient> => ({
  name: b.name?.trim(),
  company: b.company?.trim() || null,
  jobtitle: b.jobTitle?.trim() || null,
  email: b.email?.trim() || null,
  phone: b.phone?.trim() || null,
  stage: b.stage ?? "lead",
  valuegbp: typeof b.valueGBP === "number" ? b.valueGBP : null,
  tags: Array.isArray(b.tags) ? b.tags : [],
  siteids: Array.isArray(b.siteIds) ? b.siteIds : [],
  activity: Array.isArray(b.activity) ? b.activity : [],
  documents: Array.isArray(b.documents) ? b.documents : [],
});

export async function POST(req: Request) {
  const tenantHdr = req.headers.get("x-outseta-account");
  const tenant = tenantHdr ?? (DEV_TENANT_FALLBACK ? "UNSET" : null);
  const userUid = req.headers.get("x-outseta-user") || null;

  // DEBUG LOGS (visible in your Next.js server console)
  console.log("[POST /api/clients] tenant:", tenantHdr, "→ using:", tenant);

  if (!tenant) {
    return NextResponse.json(
      { error: "Missing tenant (x-outseta-account header not present)" },
      { status: 401 }
    );
  }

  try {
    const body = await req.json();
    if (!body?.name?.trim()) {
      return NextResponse.json({ error: "Name required" }, { status: 400 });
    }

    const payload = apiToDb({
      ...body,
      tags: body.tags ?? [],
      siteIds: body.siteIds ?? [],
      activity: [],
      documents: [],
    }) as any;

    payload.account_uid = tenant;
    payload.created_by = userUid;

    const { data, error } = await supabaseAdmin
      .from("clients")
      .insert(payload)
      .select("*")
      .single();

    if (error) {
      console.error("[POST /api/clients] supabase error:", error.message);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({
      id: data.id,
      name: data.name,
      company: data.company ?? undefined,
      jobTitle: data.jobtitle ?? undefined,
      email: data.email ?? undefined,
      phone: data.phone ?? undefined,
      stage: data.stage ?? "lead",
      valueGBP: data.valuegbp ?? undefined,
      tags: data.tags ?? [],
      siteIds: data.siteids ?? [],
      activity: data.activity ?? [],
      documents: data.documents ?? [],
      createdAt: data.created_at,
    });
  } catch (e: any) {
    console.error("[POST /api/clients] exception:", e);
    return NextResponse.json({ error: e?.message ?? "Unknown error" }, { status: 500 });
  }
}

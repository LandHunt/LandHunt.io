// types/outseta.d.ts
declare global {
  interface Window {
    Outseta?: any;
    o_options?: any;
  }
}
export {};
